package com.jesusegr1997.multipanel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xFF0B1120.toInt())
        }
        val title = TextView(this).apply {
            text = "MultiPanel"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Barra lateral de aplicaciones\n\nActiva el permiso para mostrar sobre otras aplicaciones. Después podrás abrir MultiPanel desde la pestaña del borde."
            textSize = 15f
            setTextColor(0xFFB8C3D8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 28)
        }
        val permission = Button(this).apply {
            text = "Conceder permiso de superposición"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startSidebar()
            }
        }
        val start = Button(this).apply {
            text = "Iniciar MultiPanel"
            setOnClickListener { if (Settings.canDrawOverlays(this@MainActivity)) startSidebar() else permission.performClick() }
        }
        val stop = Button(this).apply {
            text = "Detener MultiPanel"
            setOnClickListener { stopService(Intent(this@MainActivity, SidebarService::class.java)) }
        }
        root.addView(title)
        root.addView(description)
        root.addView(permission)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) startSidebar()
    }

    private fun startSidebar() {
        val intent = Intent(this, SidebarService::class.java)
        startService(intent)
    }
}
