package com.jesusegr1997.multipanel

import android.app.Service
import android.app.ActivityOptions
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import kotlin.math.roundToInt

class SidebarService : Service() {
    private lateinit var wm: WindowManager
    private var handleRight: View? = null
    private var handleLeft: View? = null
    private var panel: View? = null
    private var actionSheet: View? = null
    private var selectedPackage: String? = null
    private var selectedLabel: String = ""
    private var selectedIcon: android.graphics.drawable.Drawable? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var isRight = true
    private var downX = 0f
    private var downY = 0f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showHandle(true)
        showHandle(false)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    private fun overlayType() = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun glass(radius: Int = 22): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radius).toFloat()
        setColor(0xE91A2235.toInt())
        setStroke(dp(1), 0x667E8EB8)
    }

    private fun showHandle(right: Boolean) {
        if ((right && handleRight != null) || (!right && handleLeft != null)) return
        val v = View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat(); setColor(0xDD8E83E8.toInt()); setStroke(dp(1), 0x88FFFFFF.toInt())
            }
            setOnClickListener { if (panel == null) showPanel(right) else hidePanel() }
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; true }
                    MotionEvent.ACTION_UP -> {
                        val dy = e.rawY - downY
                        if (kotlin.math.abs(dy) > dp(18)) moveHandle(right, e.rawY)
                        else if (panel == null) showPanel(right) else hidePanel()
                        true
                    }
                    else -> true
                }
            }
        }
        val p = WindowManager.LayoutParams(dp(13), dp(66), overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = (if (right) Gravity.RIGHT else Gravity.LEFT) or Gravity.CENTER_VERTICAL
            x = 0; y = 0
        }
        if (right) handleRight = v else handleLeft = v
        wm.addView(v, p)
    }

    private fun moveHandle(right: Boolean, rawY: Float) {
        val p = (if (right) handleRight else handleLeft)?.layoutParams as? WindowManager.LayoutParams ?: return
        run {
            val screen = resources.displayMetrics.heightPixels
            p.y = (rawY - screen / 2f).toInt().coerceIn(-screen / 2 + dp(70), screen / 2 - dp(70))
            try { wm.updateViewLayout(if (right) handleRight else handleLeft, p) } catch (_: Exception) {}
        }
    }

    private fun showPanel(right: Boolean) {
        isRight = right
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(24)
            setPadding(dp(7), dp(10), dp(7), dp(10))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val title = TextView(this).apply { text = "✦"; textSize = 19f; setTextColor(0xFFE5E9FF.toInt()); gravity = Gravity.CENTER }
        header.addView(title, LinearLayout.LayoutParams(dp(46), dp(35)))
        root.addView(header)
        val scroll = ScrollView(this).apply { isFillViewport = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { packageManager.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }
        for (app in apps) {
            val icon = ImageView(this).apply {
                setImageDrawable(packageManager.getApplicationIcon(app))
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8))
                background = rounded(16, 0x22FFFFFF)
                contentDescription = packageManager.getApplicationLabel(app)
                setOnClickListener { selectApp(app) }
            }
            val lp = LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(8) }
            list.addView(icon, lp)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(dp(64), 0, 1f))
        val p = WindowManager.LayoutParams(dp(82), dp(560).coerceAtMost(resources.displayMetrics.heightPixels - dp(80)), overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = (if (right) Gravity.RIGHT else Gravity.LEFT) or Gravity.CENTER_VERTICAL; x = dp(18)
        }
        panel = root; panelParams = p
        wm.addView(root, p)
        (if (right) handleRight else handleLeft)?.visibility = View.GONE
    }

    private fun rounded(radius: Int, color: Int) = GradientDrawable().apply { cornerRadius = dp(radius).toFloat(); setColor(color) }

    private fun selectApp(app: ApplicationInfo) {
        selectedPackage = app.packageName
        selectedLabel = packageManager.getApplicationLabel(app).toString()
        selectedIcon = packageManager.getApplicationIcon(app)
        showActions()
    }

    private fun showActions() {
        actionSheet?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = glass(20); setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val icon = ImageView(this).apply { setImageDrawable(selectedIcon); scaleType = ImageView.ScaleType.FIT_CENTER }
        sheet.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(8) })
        val floating = actionButton("▢", "Ventana flotante") { launchSelected(true) }
        val split = actionButton("◫", "Pantalla dividida") { launchSelected(false) }
        sheet.addView(floating, LinearLayout.LayoutParams(0, dp(62), 1f).apply { rightMargin = dp(6) })
        sheet.addView(split, LinearLayout.LayoutParams(0, dp(62), 1f))
        val p = WindowManager.LayoutParams(dp(290), dp(92), overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = (if (isRight) Gravity.RIGHT else Gravity.LEFT) or Gravity.BOTTOM
            x = dp(8); y = dp(80)
        }
        actionSheet = sheet
        wm.addView(sheet, p)
    }

    private fun actionButton(symbol: String, label: String, action: () -> Unit) = TextView(this).apply {
        text = "$symbol\n$label"; textSize = 10f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt()); background = rounded(13, 0x665D5AC0); setPadding(dp(3), 0, dp(3), 0); setOnClickListener { action() }
    }

    private fun launchSelected(floating: Boolean) {
        val pkg = selectedPackage ?: return
        val launch = packageManager.getLaunchIntentForPackage(pkg) ?: return
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val bounds = if (floating) {
            val left = dp(24); val top = dp(120)
            Rect(left, top, left + (screenW * 0.72f).toInt(), top + (screenH * 0.52f).toInt())
        } else {
            launch.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
            Rect(0, 0, screenW / 2, screenH)
        }
        try {
            val options = ActivityOptions.makeBasic().setLaunchBounds(bounds)
            startActivity(launch, options.toBundle())
            hidePanel()
        } catch (e: Exception) {
            Toast.makeText(this, "Android/HyperOS no permitió abrir este modo. Prueba desde Recientes.", Toast.LENGTH_LONG).show()
        }
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        actionSheet?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        actionSheet = null
        panel = null; panelParams = null
        handleRight?.visibility = View.VISIBLE
        handleLeft?.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        hidePanel()
        handleRight?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handleLeft?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handleRight = null; handleLeft = null
        super.onDestroy()
    }
}
